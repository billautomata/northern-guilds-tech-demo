<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="tileset_dirt" tilewidth="64" tileheight="64" tilecount="21" columns="7">
 <image source="../tiles/dirt_01/tilemap_dirt.png" width="448" height="192"/>
</tileset>
